#pragma once
#include <iostream>
#include "bString.h"

using namespace std;